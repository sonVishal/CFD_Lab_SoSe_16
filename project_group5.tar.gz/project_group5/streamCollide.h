
#ifndef _STREAMING_H_
#define _STREAMING_H_
#include "LBDefinitions.h"

void streamCollide(t_component *c, const t_procData * const procData);
#endif
